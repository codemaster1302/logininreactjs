export const starOne = (
   <ul className="star-rating">
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
   </ul>
);

export const starTwo = (
   <ul className="star-rating">
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
   </ul>
);

export const starThree = (
   <ul className="star-rating">
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
   </ul>
);

export const starFour = (
   <ul className="star-rating">
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star-half-empty" />
      </li>
   </ul>
);

export const starFive = (
   <ul className="star-rating">
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="mr-sm-1">
         <i className="fa fa-star" />
      </li>
   </ul>
);
