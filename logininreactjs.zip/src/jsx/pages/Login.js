
import React, { useState, useEffect, useRef } from 'react'
import { Link, NavLink,BrowserRouter,useHistory   } from 'react-router-dom';
//import { browserHistory } from 'react-router'
import config from '../../config';
import Form from "react-validation/build/form";
import Input from "react-validation/build/input";
import CheckButton from "react-validation/build/button";
import {getLogin} from '../components/Actions/AuthAction'
import logo from "../../images/logo.png";
// import { useDispatch } from 'react-redux';
// import { login } from '../../features/userSlice';
const required = (value) => {
   if (!value) {
     return (
       <div className="alert alert-danger" role="alert">
         This field is required!
       </div>
     );
   }
 };
const Login = ({ props }) => {
   const form = useRef();
  const checkBtn = useRef();
  const [username, setUsername] = useState({ value:  '', error: '', isRequired: true });
  const [password, setPassword] = useState({ value:  '', error: '', isRequired: true });

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  //const [token, setToken] = useState(false);
 //const dispatch = useDispatch();
  let history = useHistory();

  useEffect(() => {

    
    
  }, [])

  // const onChangeUsername = (e) => {
  //   const username = e.target.value;
  //  // alert(username);
  //   setUsername(username);
  // };

  // const onChangePassword = (e) => {
  //   const password = e.target.value;
  //   setPassword(password);
  // };

  const handleLogin = (e) => {
    e.preventDefault();
    //localStorage.setItem("test", 'dfasdf');
    //alert(password);return false;

    setMessage("");
    setLoading(true);

    form.current.validateAll();
    if (checkBtn.current.context._errors.length === 0) {
    getLogin({ "email":username.value,"password":password.value })
    .then(res => {
             //alert(res.status);
             if(res.status){
               setMessage("Login Successfully...");
               history.push("/home");
               //setToken(res.status);
               // window.location.reload();
            //   dispatch(
            //     login({
            //       loggedIn:true,
            //       status:res.status,
            //     })
            //   );

             }else{
              history.push("/");
                localStorage.removeItem("token");
                setLoading(false);
                setMessage(res.msg);
             }
      })
} else {
    setLoading(false);
  }
    
  };

   return (
      <div className="authincation h-100 p-meddle">
         <div className="container h-100">
            <div className="row justify-content-center h-100 align-items-center">
               <div className="col-md-6">
                  <div className="authincation-content">
                     <div className="row no-gutters">
                        <div className="col-xl-12">
                           <div className="auth-form">
                           <div className="text-center mb-4">
                           <img className="text-center logo-abbr" src={logo} alt="" style={{width:"150px"}}/>
                           </div>
                              <h4 className="text-center mb-4">
                              
                                 Sign in your account
                              </h4>
                              <Form ref={form}>
                                 <div className="form-group">
                                    <label className="mb-1">
                                       <strong>Email</strong>
                                    </label>
                                    <Input
              type="text"
              className="form-control"
              placeholder="Enter Email"
              name="username"
              value={username.value}
              onChange={(e) => setUsername({ ...username, value: e.target.value })}
              validations={[required]}
            />
                                 </div>
                                 <div className="form-group">
                                    <label className="mb-1">
                                       <strong>Password</strong>
                                    </label>
                                    <Input
              type="password"
              className="form-control"
              name="password"
              placeholder="Enter Password"
              value={password.value}
              onChange={(e) => setPassword({ ...password, value: e.target.value })}
             validations={[required]}
            />
                                 </div>
                                 <div className="form-row d-flex justify-content-between mt-4 mb-2">
                                    <div className="form-group">
                                       <div className="custom-control custom-checkbox ml-1">
                                          <input
                                             type="checkbox"
                                             className="custom-control-input"
                                             id="basic_checkbox_1"
                                          />
                                          <label
                                             className="custom-control-label"
                                             htmlFor="basic_checkbox_1"
                                          >
                                             Remember my preference
                                          </label>
                                       </div>
                                    </div>
                                    <div className="form-group">
                                       <Link to="/page-forgot-password">
                                          Forgot Password?
                                       </Link>
                                    </div>
                                 </div>
                                 <div className="text-center">
                                
            <button onClick={handleLogin} className="btn btn-primary btn-block">
              LOGIN
            </button>
            {loading && (
                <span className="spinner-border spinner-border-sm"></span>
              )}
          
                                 </div>
                                 {message && (
            <div className="form-group">
              <div className="alert alert-danger" role="alert">
                {message}
              </div>
            </div>
          )}
          <CheckButton style={{ display: "none" }} ref={checkBtn} />
                              </Form>
                              <div className="new-account mt-3">
                                 <p>
                                    Don't have an account?{" "}
                                    <Link
                                       className="text-primary"
                                       to="/page-register"
                                    >
                                       Sign up
                                    </Link>
                                 </p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
};

export default Login;
