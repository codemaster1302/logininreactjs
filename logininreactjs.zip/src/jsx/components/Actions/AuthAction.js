import * as axios from 'axios';
import CONFIG from '../../../config';
//import { getAuthHeader } from '../../utils';
import { Link, NavLink,BrowserRouter,useHistory   } from 'react-router-dom';



// Generate token
// export const getLogin = (model) => {
//     // const model={"id":"-1"}
//     const url = `${CONFIG.BASE_URL}/login`;
//     return axios.post(url, model)
//         .then((response) => {
//           localStorage.setItem("token",response.data.access_token)
         
//         });
// }


//get state
export const getLogin = (model) => {
  console.log(model);
  const url = `${CONFIG.BASE_URL}/login`;
  return axios.post(url, model)
      .then((response) => {
          if (response.data.status) {
            //alert(response.data.roles[0].role_name);
            localStorage.setItem("status", response.data.status);
            localStorage.setItem("token", response.data.jwt);
            localStorage.setItem("username", response.data.username);
            localStorage.setItem("roleid", response.data.roles[0].role_id);
            localStorage.setItem("role", response.data.roles[0].role_name);
            
          }
          return response.data;
      });
}

export const getSignup = (model) => {
  console.log(model);
  const url = `${CONFIG.BASE_URL}/signup`;
  return axios.post(url, model)
      .then((response) => {
        return response.data;
      });
}

export const getLogout = (props) => {
  localStorage.removeItem("token");
  localStorage.removeItem("status");
   // props.history.push("/");
    window.location.reload();
};

export const username  = () => {
  return localStorage.getItem("username");
};

export const roleid  = () => {
  return localStorage.getItem("roleid");
};

export const role  = () => {
  return localStorage.getItem("role");
};

// export const urlAccess  = () => {{
//     var auth = JSON.parse(localStorage.getItem('token'))
//     if(auth){
//       history.goBack()
//     }else{
//       props.history.push("/");
//     }
// }




// //get state map details
// export const getStateMapDetails = (model) => {
//   const url = `${CONFIG.BASE_URL}/govtinit/1/api/getmapdetails`;
//   return axios.post(url, model, getAuthHeader())
//       .then((response) => {
//           return response.data;
//       });
// }


// //get all ministry
// export const selectAllMinistry = (model) => {
//   const url = `${CONFIG.BASE_URL}/master/1/api/getallministry`;
//   return axios.post(url, model, getAuthHeader())
//       .then((response) => {
//           return response.data;
//       });
// }


// //get all department
// export const selectAllDepartment = (model) => {
//   const url = `${CONFIG.BASE_URL}/govtinit/1/api/getalldepartment`;
//   return axios.post(url, model, getAuthHeader())
//       .then((response) => {
//           return response.data;
//       });
// }

// //get all Central Gov Details
// export const getCentralGovDetails = (model) => {
//   const url = `${CONFIG.BASE_URL}/govtinit/1/api/getsearchcentrelgovdetails`;
//   return axios.post(url, model, getAuthHeader())
//       .then((response) => {
//           return response.data;
//       });
// }


// //get single central Gov Details
// export const getSingleCentralGovDetails = (model) => {
//   const url = `${CONFIG.BASE_URL}/govtinit/1/api/getsinglecentrelgovdetails`;
//   return axios.post(url, model, getAuthHeader())
//       .then((response) => {
//           return response.data;
//       });
// }

// //get single central Gov Details
// export const getFilterDepartment = (model) => {
//     const url = `${CONFIG.BASE_URL}/govtinit/1/api/selectcentraldepartment`;
//     return axios.post(url, model, getAuthHeader())
//         .then((response) => {
//             return response.data;
//         });
//   }

