import * as React from 'react';
import { Route, Switch,Redirect } from 'react-router-dom';

function Protected(props){

const Cmp = props.Cmp
var auth = localStorage.getItem('token')

console.log(auth)

return <div> {auth ? <Cmp />: <Redirect to="/"></Redirect>}</div>

}

export default Protected;