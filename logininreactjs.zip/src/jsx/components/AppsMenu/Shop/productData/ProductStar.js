export const starOne = (
   <ul className="star-rating">
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
   </ul>
);

export const starTwo = (
   <ul className="star-rating">
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
   </ul>
);

export const starThree = (
   <ul className="star-rating">
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
   </ul>
);

export const starFour = (
   <ul className="star-rating">
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star-half-empty" />
      </li>{" "}
   </ul>
);

export const starFive = (
   <ul className="star-rating">
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
      <li>
         <i className="fa fa-star" />
      </li>{" "}
   </ul>
);
